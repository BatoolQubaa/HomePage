---
name: Scroll animation bounds
description: Keep scroll-linked visual transitions reachable at the document’s scroll limit.
---

For scroll-linked elements that must reach a final state, clamp the animation endpoint to the document’s maximum scroll or reserve enough page space for the endpoint. Verify the final state at the page bottom and that scrolling back reverses it.

**Why:** The browser cannot scroll beyond the document’s maximum offset, so an endpoint beyond that limit leaves the animation and dependent content fade incomplete.

**How to apply:** When measuring an animation path, compare its preferred endpoint with `scrollHeight - innerHeight`; test both the bottom state and the reversed top state in a browser.
