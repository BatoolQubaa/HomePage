import { useLayoutEffect, useRef, useState } from 'react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { motion, useScroll, useTransform } from 'framer-motion';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Toaster } from '@/components/ui/toaster';
import { ErrorBoundary } from '@/components/error-boundary';
import logoAsset from '@assets/SKYTRACE_Orbital_Logo_1793989511948.png';
import earthAsset from '@assets/Earth_at_Night_with_Sunrise_Glow_1793989460873.png';
import telescopeAsset from '@assets/SPHEREx_Telescope_with_Solar_Panels_1793989483407.png';

const queryClient = new QueryClient();

const assets = {
  logo: logoAsset,
  earth: earthAsset,
  telescope: telescopeAsset,
};

type TelescopeMotionBounds = {
  startTop: number;
  endTop: number;
  endScroll: number;
  startX: number;
  endX: number;
  endScale: number;
};

const initialMotionBounds: TelescopeMotionBounds = {
  startTop: 100,
  endTop: 760,
  endScroll: 520,
  startX: 110,
  endX: 0,
  endScale: 1,
};

function Navigation() {
  return (
    <header className="site-header">
      <Link href="/" className="brand" aria-label="SKYTRACE home">
        <img src={assets.logo} alt="SKYTRACE" />
      </Link>
    </header>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <Link href="/" className="brand footer-brand" aria-label="SKYTRACE home">
        <img src={assets.logo} alt="SKYTRACE" />
      </Link>
      <nav className="footer-links" aria-label="Footer navigation">
        <Link href="/">Home</Link>
        <Link href="/explorer">Explorer</Link>
      </nav>
    </footer>
  );
}

function HomePage() {
  const heroRef = useRef<HTMLElement>(null);
  const storyVisualRef = useRef<HTMLDivElement>(null);
  const { scrollY } = useScroll();
  const [motionBounds, setMotionBounds] = useState(initialMotionBounds);

  useLayoutEffect(() => {
    const measureMotionPath = () => {
      const hero = heroRef.current;
      const storyVisual = storyVisualRef.current;
      if (!hero || !storyVisual) return;

      const isMobile = window.innerWidth <= 640;
      const baseWidth = isMobile
        ? Math.min(window.innerWidth * 0.86, 440)
        : Math.min(Math.max(window.innerWidth * 0.35, 320), 500);
      const baseHeight = baseWidth * (1035 / 1520);
      const visualRect = storyVisual.getBoundingClientRect();
      const storyCenter = window.scrollY + visualRect.top + visualRect.height / 2;
      const startCenter = hero.getBoundingClientRect().height * (isMobile ? 0.22 : 0.19);
      const preferredEndScroll = storyCenter - window.innerHeight * 0.48;
      const maximumScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      const endScroll = Math.max(1, Math.min(preferredEndScroll, maximumScroll));
      const anchoredRight = window.innerWidth * (isMobile ? 0.06 : 0.12);
      const anchoredCenter = window.innerWidth - anchoredRight - baseWidth / 2;
      const startCenterX = window.innerWidth * (isMobile ? 0.76 : 0.78);
      const endCenterX = window.innerWidth * (isMobile ? 0.68 : 0.71);

      setMotionBounds({
        startTop: startCenter - baseHeight / 2,
        endTop: storyCenter - baseHeight / 2,
        endScroll,
        startX: startCenterX - anchoredCenter,
        endX: endCenterX - anchoredCenter,
        endScale: isMobile ? 0.62 : 1,
      });
    };

    measureMotionPath();
    window.addEventListener('resize', measureMotionPath);
    const resizeObserver = new ResizeObserver(measureMotionPath);
    if (heroRef.current) resizeObserver.observe(heroRef.current);
    if (storyVisualRef.current) resizeObserver.observe(storyVisualRef.current);

    return () => {
      window.removeEventListener('resize', measureMotionPath);
      resizeObserver.disconnect();
    };
  }, []);

  const telescopeX = useTransform(
    scrollY,
    [0, motionBounds.endScroll],
    [motionBounds.startX, motionBounds.endX],
  );
  const telescopeY = useTransform(
    scrollY,
    [0, motionBounds.endScroll],
    [motionBounds.startTop, motionBounds.endTop],
  );
  const telescopeScale = useTransform(
    scrollY,
    [0, motionBounds.endScroll],
    [0.14, motionBounds.endScale],
  );
  const storyOpacity = useTransform(
    scrollY,
    [motionBounds.endScroll * 0.72, motionBounds.endScroll],
    [0, 1],
  );

  return (
    <main className="site-shell">
      <div className="space-backdrop" aria-hidden="true" />
      <motion.img
        className="shared-telescope"
        src={assets.telescope}
        alt=""
        aria-hidden="true"
        style={{
          x: telescopeX,
          y: telescopeY,
          scale: telescopeScale,
        }}
      />
      <Navigation />
      <section ref={heroRef} className="hero" aria-labelledby="hero-title">
        <img className="earth-art" src={assets.earth} alt="" />
        <div className="hero-copy">
          <h1 id="hero-title">
            <span className="headline-first">The Sky Is</span>
            <span className="headline-second">Never Still.</span>
          </h1>
          <p>Beyond what the eye can see, the universe is always changing. Explore its hidden story through NASA SPHEREx.</p>
          <Link href="/explorer" className="primary-cta">
            Start Exploring <span aria-hidden="true">→</span>
          </Link>
        </div>
        <a className="scroll-cue" href="#powered" aria-label="Scroll to learn about SPHEREx">
          <span className="chevron-arrow" aria-hidden="true" />
        </a>
      </section>
      <section className="story" id="powered" aria-labelledby="story-title">
        <motion.div ref={storyVisualRef} className="story-visual" aria-hidden="true" />
        <motion.div className="story-copy" style={{ opacity: storyOpacity }}>
          <div className="eyebrow">POWERED BY SPHEREx</div>
          <h2 id="story-title">See What Time<br /><span>Reveals.</span></h2>
          <p>NASA&apos;s SPHEREx observes the sky in infrared light, revealing what our eyes cannot see. SKYTRACE brings these observations together across time, helping you spot changes, investigate moving-object candidates, and uncover the stories hidden between them.</p>
        </motion.div>
      </section>
      <Footer />
    </main>
  );
}

function ExplorerPage() {
  return (
    <main className="site-shell">
      <div className="space-backdrop" aria-hidden="true" />
      <Navigation />
      <section className="placeholder-page">
        <h1>Explorer</h1>
        <p>The SKYTRACE explorer is coming soon.</p>
        <Link href="/" className="primary-cta">Return Home <span aria-hidden="true">→</span></Link>
      </section>
      <Footer />
    </main>
  );
}

function RoutedContent() {
  const [location] = useLocation();
  return (
    <ErrorBoundary resetKey={location}>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/explorer" component={ExplorerPage} />
        <Route>
          <main className="site-shell">
            <div className="space-backdrop" aria-hidden="true" />
            <Navigation />
            <section className="placeholder-page">
              <h1>Page not found</h1>
              <Link href="/" className="primary-cta">Return Home <span aria-hidden="true">→</span></Link>
            </section>
          </main>
        </Route>
      </Switch>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <RoutedContent />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
